<script type="module">
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/11.5.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/11.5.0/firebase-analytics.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  const firebaseConfig = {
    apiKey: "AIzaSyAfSOMaqi2IgAJoi7awVBuroBpJhbNfbxw",
    authDomain: "emestudiosvirtual.firebaseapp.com",
    projectId: "emestudiosvirtual",
    storageBucket: "emestudiosvirtual.firebasestorage.app",
    messagingSenderId: "431778838187",
    appId: "1:431778838187:web:120fa8784b22d7f968a9ee",
    measurementId: "G-PW4457MCYV"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
</script>