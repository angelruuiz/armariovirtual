document.addEventListener("DOMContentLoaded", function () {
    cargarOutfits();

    document.getElementById("logout")?.addEventListener("click", function () {
        fetch("../php/logout.php", { method: "POST" })
            .then(response => response.text())
            .then(() => window.location.href = "login.html");
    });
});

function cargarOutfits() {
    fetch("../php/get_outfits.php")
        .then(response => response.json())
        .then(outfits => {
            const container = document.getElementById("outfits-container");
            container.innerHTML = "";
            
            outfits.forEach(outfit => {
                const outfitDiv = document.createElement("div");
                outfitDiv.classList.add("outfit");
                
                const title = document.createElement("h3");
                title.textContent = outfit.nombre;
                outfitDiv.appendChild(title);
                
                const images = document.createElement("div");
                images.classList.add("outfit-images");
                
                outfit.prendas.split(",").forEach(imgUrl => {
                    const img = document.createElement("img");
                    img.src = imgUrl;
                    img.alt = "Prenda";
                    images.appendChild(img);
                });
                
                outfitDiv.appendChild(images);
                container.appendChild(outfitDiv);
            });
        })
        .catch(error => console.error("Error cargando outfits:", error));
}