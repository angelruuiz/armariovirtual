<?php
require 'db.php';
session_start();

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(["error" => "No has iniciado sesión"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_usuario = $_SESSION['id_usuario'];
    $id_outfit = $_POST['id_outfit'] ?? '';
    $red_social = $_POST['red_social'] ?? '';
    
    if (!empty($id_outfit) && in_array($red_social, ['Instagram', 'Facebook', 'Twitter'])) {
        try {
            $stmt = $conn->prepare("INSERT INTO Compartidos (id_usuario, id_outfit, red_social) VALUES (:id_usuario, :id_outfit, :red_social)");
            $stmt->bindParam(':id_usuario', $id_usuario);
            $stmt->bindParam(':id_outfit', $id_outfit);
            $stmt->bindParam(':red_social', $red_social);
            $stmt->execute();
            
            echo json_encode(["success" => "Outfit compartido en $red_social"]);
        } catch (PDOException $e) {
            echo json_encode(["error" => $e->getMessage()]);
        }
    } else {
        echo json_encode(["error" => "Datos inválidos"]);
    }
}
?>