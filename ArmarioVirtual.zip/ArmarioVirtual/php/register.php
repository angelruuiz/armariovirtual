<?php
require 'db.php'; // Importar la conexión a la base de datos

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos enviados desde el formulario
    $nombre = $_POST['nombre'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Verificar que todos los campos estén completados
    if (!empty($nombre) && !empty($email) && !empty($password)) {
        // Encriptar la contraseña
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        
        try {
            // Preparar la consulta SQL para insertar datos
            $stmt = $conn->prepare("INSERT INTO Usuarios (nombre, email, contraseña) VALUES (:nombre, :email, :password)");
            // Asignar valores a los parámetros
            $stmt->bindParam(':nombre', $nombre);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':password', $hashed_password);
            // Ejecutar la consulta
            $stmt->execute();
            
            echo "Registro exitoso";
        } catch (PDOException $e) {
            // Mostrar el error en caso de fallo
            echo "Error: " . $e->getMessage();
        }
    } else {
        echo "Por favor, completa todos los campos";
    }
}
?>