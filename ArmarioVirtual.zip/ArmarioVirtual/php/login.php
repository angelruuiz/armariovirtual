<?php
$host = 'localhost';        // Nombre del servidor (en este caso, es local)
$dbname = 'armariovirtual'; // Nombre de tu base de datos
$username = 'root';         // Usuario por defecto para MySQL (si no has cambiado la configuración)
$password = '';             // Contraseña vacía (si no tienes contraseña configurada en MySQL)

try {
    // Intentamos conectar a la base de datos
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Activamos los errores para ver si pasa algo

    // Si la conexión es exitosa, redirigimos al usuario
    header("Location:/html/dashboard.html");
    exit(); // Importante: cerramos el script después de redirigir
} catch (PDOException $e) {
    // Si ocurre un error, lo mostramos
    die("Error de conexión: " . $e->getMessage());
}
?>
