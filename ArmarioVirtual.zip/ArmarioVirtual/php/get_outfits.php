<?php
require 'db.php';
session_start();

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(["error" => "No has iniciado sesión"]);
    exit;
}

$id_usuario = $_SESSION['id_usuario'];

try {
    $stmt = $conn->prepare("SELECT o.id_outfit, o.nombre, o.fecha_creacion, GROUP_CONCAT(p.imagen_url) AS prendas 
                            FROM Outfits o 
                            JOIN Outfit_Prendas op ON o.id_outfit = op.id_outfit 
                            JOIN Prendas p ON op.id_prenda = p.id_prenda 
                            WHERE o.id_usuario = :id_usuario 
                            GROUP BY o.id_outfit");
    $stmt->bindParam(':id_usuario', $id_usuario);
    $stmt->execute();
    $outfits = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($outfits);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>