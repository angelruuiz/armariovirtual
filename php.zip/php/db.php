<?php
$host = 'localhost';      // Nombre del servidor (en este caso es local)
$dbname = 'armariovirtual'; // Nombre de tu base de datos
$username = 'usuario';     // Nombre de usuario para acceder a la base de datos
$password = 'contraseña';  // Contraseña del usuario

try {
    // Intentamos conectar a la base de datos
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Activamos los errores para ver si pasa algo
    echo "Conexión exitosa";  // Si llegamos aquí, la conexión es correcta
} catch (PDOException $e) {
    // Si ocurre un error, lo mostramos
    die("Error de conexión: " . $e->getMessage());
}
?>
