<?php
require 'db.php';
session_start();

if (!isset($_SESSION['id_usuario'])) {
    echo "No has iniciado sesión";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_usuario = $_SESSION['id_usuario'];
    $imagen_url = $_POST['imagen_url'] ?? '';
    $tipo = $_POST['tipo'] ?? '';
    $color = $_POST['color'] ?? '';
    $temporada = $_POST['temporada'] ?? '';
    $estilo = $_POST['estilo'] ?? '';
    
    if (!empty($imagen_url) && !empty($tipo) && !empty($temporada) && !empty($estilo)) {
        try {
            $stmt = $conn->prepare("INSERT INTO Prendas (id_usuario, imagen_url, tipo, color, temporada, estilo) VALUES (:id_usuario, :imagen_url, :tipo, :color, :temporada, :estilo)");
            $stmt->bindParam(':id_usuario', $id_usuario);
            $stmt->bindParam(':imagen_url', $imagen_url);
            $stmt->bindParam(':tipo', $tipo);
            $stmt->bindParam(':color', $color);
            $stmt->bindParam(':temporada', $temporada);
            $stmt->bindParam(':estilo', $estilo);
            $stmt->execute();
            
            echo "Prenda subida con éxito";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    } else {
        echo "Todos los campos obligatorios deben estar llenos";
    }
}
?>